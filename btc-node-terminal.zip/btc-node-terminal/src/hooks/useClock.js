import { useState, useEffect } from 'react'
import { ts } from '../utils/helpers.js'

export function useClock() {
  const [clock, setClock] = useState(ts())
  useEffect(() => {
    const id = setInterval(() => setClock(ts()), 1000)
    return () => clearInterval(id)
  }, [])
  return clock
}

import { useState, useEffect, useRef } from 'react'
import { SYNCED_PERCENT_INIT, BLOCK_HEIGHT } from '../utils/constants.js'
import { calcStorage, calcETA } from '../utils/helpers.js'

export function useSync() {
  const [syncPct, setSyncPct] = useState(SYNCED_PERCENT_INIT)
  const [blocksNow, setBlocksNow] = useState(
    Math.floor(BLOCK_HEIGHT * (SYNCED_PERCENT_INIT / 100))
  )
  const syncRef = useRef(syncPct)

  useEffect(() => {
    const interval = setInterval(() => {
      setSyncPct(prev => {
        const next = Math.min(100, prev + 0.002)
        syncRef.current = next
        setBlocksNow(Math.floor(BLOCK_HEIGHT * (next / 100)))
        return next
      })
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  const storage = calcStorage(syncPct)
  const eta     = calcETA(syncPct)

  return { syncPct, blocksNow, storage, eta }
}

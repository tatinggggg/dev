import { useState, useCallback } from 'react'
import { rpcExec, ALL_CMDS } from '../utils/rpc.js'
import { logCommand } from '../utils/session.js'
import { ts, fmtDT } from '../utils/helpers.js'
import { SYNCED_PERCENT_INIT, USERNAME } from '../utils/constants.js'
import { calcStorage, calcETA } from '../utils/helpers.js'
import { BLOCKCHAIN_SIZE_GB, MB_PER_SEC, CPU_SPEED_GHZ } from '../utils/constants.js'

export function useTerminal(syncPct, blocksNow, loginInfo) {
  const [lines, setLines]         = useState([])
  const [cmdHistory, setCmdHistory] = useState([])
  const [histIdx, setHistIdx]     = useState(-1)
  const [rpcLog, setRpcLog]       = useState([])
  const [input, setInput]         = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [selSug, setSelSug]       = useState(0)

  const appendLines = useCallback((newLines) => {
    setLines(prev => [...prev, ...newLines, { t: 'spacer' }])
  }, [])

  const clearLines = useCallback(() => setLines([]), [])

  const runCommand = useCallback((raw) => {
    raw = raw.trim()
    if (!raw) return

    setCmdHistory(h => [raw, ...h.slice(0, 49)])
    setHistIdx(-1)
    setSuggestions([])
    setInput('')

    // push to sidebar RPC log
    setRpcLog(l => [{ ts: ts(), cmd: raw }, ...l.slice(0, 49)])

    // record to session storage
    logCommand(raw)

    if (raw.toLowerCase() === 'clear') { clearLines(); return }

    const result = rpcExec(raw, syncPct, blocksNow)
    if (!result) { clearLines(); return }

    appendLines([{ t: 'prompt', v: raw }, ...result])
  }, [syncPct, blocksNow, appendLines, clearLines])

  const handleInput = useCallback((val) => {
    setInput(val)
    if (val.length > 0) {
      const m = ALL_CMDS.filter(c => c.startsWith(val.toLowerCase()))
      setSuggestions(m)
      setSelSug(0)
    } else {
      setSuggestions([])
    }
  }, [])

  const handleKey = useCallback((e, inputEl) => {
    if (e.key === 'Enter') {
      runCommand(input)
    } else if (e.key === 'Tab') {
      e.preventDefault()
      if (suggestions.length) {
        setInput(suggestions[selSug] || suggestions[0])
        setSuggestions([])
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (suggestions.length) {
        setSelSug(s => Math.max(0, s - 1))
      } else {
        setHistIdx(i => {
          const next = Math.min(i + 1, cmdHistory.length - 1)
          setInput(cmdHistory[next] || '')
          return next
        })
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (suggestions.length) {
        setSelSug(s => Math.min(suggestions.length - 1, s + 1))
      } else {
        setHistIdx(i => {
          const next = Math.max(-1, i - 1)
          setInput(next === -1 ? '' : cmdHistory[next])
          return next
        })
      }
    } else if (e.key === 'Escape') {
      setSuggestions([])
    }
  }, [input, suggestions, selSug, cmdHistory, runCommand])

  const boot = useCallback((loginInfo) => {
    const { prevTs, now } = loginInfo
    const s   = calcStorage(SYNCED_PERCENT_INIT)
    const eta = calcETA(SYNCED_PERCENT_INIT)
    appendLines([
      { t: 'comment', v: '╔══════════════════════════════════════════════════════╗' },
      { t: 'comment', v: '║         BITCOIN CORE v26.0.0  ●  MAINNET NODE         ║' },
      { t: 'comment', v: '╚══════════════════════════════════════════════════════╝' },
      { t: 'spacer' },
      { t: 'ok',      v: `[${ts()}] bitcoind started — daemon mode` },
      { t: 'ok',      v: `[${ts()}] Loaded block index in 3.84s` },
      { t: 'ok',      v: `[${ts()}] Bound to 0.0.0.0:8333` },
      { t: 'ok',      v: `[${ts()}] RPC server active on 127.0.0.1:8332` },
      { t: 'spacer' },
      { t: 'session', v: `Welcome, ${USERNAME}!` },
      { t: 'session', v: `Current login  : ${fmtDT(now)}` },
      { t: 'session', v: `Previous login : ${prevTs ? fmtDT(prevTs) : 'no previous record'}` },
      { t: 'spacer' },
      { t: 'info',    v: `[${ts()}] Initial Block Download in progress...` },
      { t: 'key',     v: 'progress                 :', s: `${SYNCED_PERCENT_INIT}.00%  (${s.usedGB} GB / ${BLOCKCHAIN_SIZE_GB} GB)` },
      { t: 'key',     v: 'ETA                      :', s: `~${eta.remH}h ${eta.remM}m  (~${eta.remHDec} hours)` },
      { t: 'key',     v: 'throughput               :', s: `${MB_PER_SEC.toFixed(2)} MB/s  [CPU ${CPU_SPEED_GHZ} GHz × 2.1]` },
      { t: 'key',     v: 'peers                    :', s: '47 connected' },
      { t: 'key',     v: 'storage used             :', s: `${s.usedGB} GB  (${s.utilPct}% of 1 TB)` },
      { t: 'key',     v: 'storage free             :', s: `${s.freeGB} GB` },
      { t: 'spacer' },
      { t: 'comment', v: "Type 'help' for all commands.  TAB = autocomplete.  ↑↓ = history." },
      { t: 'comment', v: "Session cmds: whoami · lastlogin · sessioninfo  |  Tab: SESSION LOG" },
      { t: 'spacer' },
    ])
  }, [appendLines])

  return {
    lines, rpcLog, input, suggestions, selSug,
    setInput, handleInput, handleKey, runCommand, boot,
  }
}

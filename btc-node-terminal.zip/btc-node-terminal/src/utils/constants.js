// ── Blockchain / sync ──────────────────────────────────────────────────────
export const BLOCKCHAIN_SIZE_GB  = 620
export const SYNCED_PERCENT_INIT = 42
export const STORAGE_TOTAL_GB    = 1000
export const CPU_SPEED_GHZ       = 3.4
export const MB_PER_SEC          = CPU_SPEED_GHZ * 2.1  // ~7.14 MB/s
export const BLOCK_HEIGHT        = 834_217
export const USERNAME            = 'bitcoin@live'

// ── Server specs ──────────────────────────────────────────────────────────
export const SERVER_SPECS = {
  cpu:      'Intel Core i7-12700K @ 3.4 GHz (12 cores / 20 threads)',
  ram:      '16 GB DDR5-4800',
  os:       'Ubuntu 22.04.4 LTS x86_64',
  bitcoind: 'Bitcoin Core v26.0.0',
  network:  '1 Gbps Ethernet',
  uptime:   '14d 07h 33m',
  peers:    47,
  inbound:  21,
  outbound: 26,
}

// ── Static UTXOs ──────────────────────────────────────────────────────────
export const FAKE_UTXOS = [
  { txid: 'a3f9b2c1d4e5f6789012345678901234567890123456789012345678901234ab', vout: 0, amount: 0.5,   confs: 12,  address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh' },
  { txid: 'b7e8c9d0e1f2345678901234567890123456789012345678901234567890bcde', vout: 1, amount: 1.2,   confs: 843, address: 'bc1qm34lsc65921cjed5cj5qhf7y2tnss5n84k7z7w' },
  { txid: 'c1d2e3f4a5b6789012345678901234567890123456789012345678901234cdef', vout: 0, amount: 0.025, confs: 3,   address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh' },
]

// ── Tab definitions ───────────────────────────────────────────────────────
export const TABS = ['terminal', 'mempool', 'peers', 'specs', 'sessionlog']

// ── localStorage keys ─────────────────────────────────────────────────────
export const SESSION_KEY = 'btcnode_sessions'
export const CURRENT_KEY = 'btcnode_current'

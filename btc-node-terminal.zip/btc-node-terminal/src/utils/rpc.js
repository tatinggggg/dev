import {
  BLOCKCHAIN_SIZE_GB, STORAGE_TOTAL_GB, CPU_SPEED_GHZ, MB_PER_SEC,
  BLOCK_HEIGHT, USERNAME, SERVER_SPECS, FAKE_UTXOS,
} from './constants.js'
import { ts, rand16, randInt, randF, calcStorage, calcETA } from './helpers.js'
import { loadSessions, getCurrentSession } from './session.js'
import { fmtDT } from './helpers.js'

export const ALL_CMDS = [
  'help', 'getblockchaininfo', 'getblockcount', 'getbestblockhash',
  'getblock', 'getblockhash', 'getnetworkinfo', 'getpeerinfo',
  'getconnectioncount', 'getmempoolinfo', 'getrawmempool', 'syncmempool',
  'createrawtx', 'fetchutxo', 'addrlookup', 'decodetx', 'sendrawtx',
  'getinfo', 'getspecs', 'syncstatus', 'whoami', 'lastlogin', 'sessioninfo', 'clear',
]

// line factory helpers
const key  = (v, s)  => ({ t: 'key',     v, s })
const cmt  = (v)     => ({ t: 'comment', v })
const info = (v)     => ({ t: 'info',    v })
const ok   = (v)     => ({ t: 'ok',      v })
const err  = (v)     => ({ t: 'error',   v })
const res  = (v)     => ({ t: 'result',  v })
const txid = (v)     => ({ t: 'txid',    v })
const hex  = (v)     => ({ t: 'hex',     v })
const cmd  = (v)     => ({ t: 'cmd',     v })
const ses  = (v)     => ({ t: 'session', v })
const wrn  = (v)     => ({ t: 'warn',    v })
const sp   = ()      => ({ t: 'spacer'      })

export function rpcExec(raw, syncPct, blocksNow) {
  const parts = raw.trim().split(/\s+/)
  const c     = parts[0].toLowerCase()
  const args  = parts.slice(1)
  const stor  = calcStorage(syncPct)
  const eta   = calcETA(syncPct)
  const sgb   = (BLOCKCHAIN_SIZE_GB * syncPct / 100).toFixed(1)

  switch (c) {
    case 'clear': return null

    case 'help': return [
      cmt('Bitcoin Core RPC — ' + USERNAME),
      cmt('─────────────────────────────────────────────────'),
      info('BLOCKCHAIN'),
      cmd('  getblockchaininfo        chain state + storage'),
      cmd('  getblockcount            current block height'),
      cmd('  getbestblockhash         tip block hash'),
      cmd('  getblock <hash>          block details'),
      cmd('  getblockhash <height>    hash at height'),
      info('NETWORK'),
      cmd('  getnetworkinfo           network & peer info'),
      cmd('  getpeerinfo              connected peers'),
      cmd('  getconnectioncount       active connections'),
      info('MEMPOOL'),
      cmd('  getmempoolinfo           mempool stats'),
      cmd('  getrawmempool            all mempool txids'),
      cmd('  syncmempool              force mempool sync'),
      info('WALLET / TRANSACTIONS'),
      cmd('  createrawtx [addr] [amt] build raw transaction'),
      cmd('  fetchutxo <addr>         UTXOs for address'),
      cmd('  addrlookup <addr>        address info & history'),
      cmd('  decodetx <hex>           decode raw tx hex'),
      cmd('  sendrawtx <hex>          broadcast transaction'),
      info('SERVER'),
      cmd('  getinfo                  node summary'),
      cmd('  getspecs                 hardware specs'),
      cmd('  syncstatus               IBD progress & ETA'),
      info('SESSION'),
      cmd('  whoami                   current user + session'),
      cmd('  lastlogin                previous login record'),
      cmd('  sessioninfo              active session details'),
      cmd('  clear                    clear terminal'),
    ]

    case 'getblockchaininfo': return [
      key('chain                    :', 'main'),
      key('blocks                   :', blocksNow.toLocaleString()),
      key('headers                  :', BLOCK_HEIGHT.toLocaleString()),
      key('bestblockhash            :', rand16(64)),
      key('difficulty               :', '83148355189239.4'),
      key('mediantime               :', String(Math.floor(Date.now() / 1000 - 300))),
      key('verificationprogress     :', (syncPct / 100).toFixed(8)),
      key('chainwork                :', rand16(64)),
      key('pruned                   :', 'false'),
      key('size_on_disk             :', `${stor.usedGB} GB  (${(stor.usedGB * 1e9).toLocaleString()} bytes)`),
      key('storage_free             :', `${stor.freeGB} GB  (${stor.utilPct}% utilization)`),
      key('softforks (taproot)      :', 'active'),
    ]

    case 'getblockcount':       return [res(blocksNow.toLocaleString())]
    case 'getbestblockhash':    return [res(rand16(64))]
    case 'getconnectioncount':  return [res(String(SERVER_SPECS.peers))]

    case 'getnetworkinfo': return [
      key('version                  :', '260000'),
      key('subversion               :', '/Satoshi:26.0.0/'),
      key('protocolversion          :', '70016'),
      key('localservices            :', '000000000000040d'),
      key('localrelay               :', 'true'),
      key('timeoffset               :', '-2'),
      key('networkactive            :', 'true'),
      key('connections              :', String(SERVER_SPECS.peers)),
      key('connections_in           :', String(SERVER_SPECS.inbound)),
      key('connections_out          :', String(SERVER_SPECS.outbound)),
      key('relayfee                 :', '0.00001000 BTC/kB'),
      key('incrementalfee           :', '0.00001000 BTC/kB'),
    ]

    case 'getpeerinfo': {
      const pfx = ['192.168.', '198.51.', '203.0.', '10.0.', '172.16.', '45.33.']
      return [
        cmt(`${SERVER_SPECS.peers} connected peers`),
        ...Array.from({ length: 6 }, (_, i) => key(
          `[${i}] ${pfx[i]}${randInt(1, 254)}.${randInt(1, 254)} :`,
          `ver=70016 ping=${randInt(10, 90)}ms blk=${(blocksNow - randInt(0, 100)).toLocaleString()} ${Math.random() > .5 ? '↑inbound' : '↓outbound'}`
        )),
      ]
    }

    case 'getmempoolinfo': return [
      key('loaded                   :', 'true'),
      key('size                     :', '18,432 transactions'),
      key('bytes                    :', '23,847,192 bytes'),
      key('usage                    :', '67,234,816 bytes'),
      key('total_fee                :', '1.84320000 BTC'),
      key('maxmempool               :', '300,000,000 bytes'),
      key('mempoolminfee            :', '0.00001000 BTC/kB'),
      key('minrelaytxfee            :', '0.00001000 BTC/kB'),
      key('fullrbf                  :', 'false'),
    ]

    case 'getrawmempool': return [
      cmt('Showing first 12 of 18,432 mempool txs:'),
      ...Array.from({ length: 12 }, () => txid(rand16(64))),
    ]

    case 'syncmempool': return [
      info(`[${ts()}] Initiating mempool sync...`),
      info(`[${ts()}] Fetching from ${SERVER_SPECS.peers} peers...`),
      ok(`[${ts()}] Received 18,432 transactions`),
      ok(`[${ts()}] Sync complete — 23.8 MB synchronized`),
      key('fee range                :', '1 – 423 sat/vB'),
      key('median fee               :', '18 sat/vB'),
    ]

    case 'syncstatus': return [
      cmt('── Initial Block Download Progress ──────────────'),
      key('status                   :', 'IBD IN PROGRESS'),
      key('progress                 :', `${syncPct.toFixed(2)}%  (${sgb} GB / ${BLOCKCHAIN_SIZE_GB} GB)`),
      key('synced blocks            :', `${blocksNow.toLocaleString()} / ${BLOCK_HEIGHT.toLocaleString()}`),
      key('remaining data           :', `${eta.remGB} GB`),
      key('throughput (est.)        :', `${MB_PER_SEC.toFixed(2)} MB/s`),
      key('ETA                      :', `~${eta.remH}h ${eta.remM}m  (~${eta.remHDec} hours)`),
      key('cpu utilization          :', `${(CPU_SPEED_GHZ * 25).toFixed(0)}%`),
      key('disk write speed         :', `${(MB_PER_SEC * 0.9).toFixed(1)} MB/s`),
      key('signature verification   :', 'libsecp256k1 (SIMD)'),
      cmt('── Storage ──────────────────────────────────────'),
      key('storage total            :', `${STORAGE_TOTAL_GB} GB  (1 TB NVMe)`),
      key('storage used             :', `${stor.usedGB} GB  (${stor.utilPct}%)`),
      key('storage free             :', `${stor.freeGB} GB`),
      key('ETA formula              :', '(remGB × 1024) / (CPU × 2.1 MB/s) / 3600'),
    ]

    case 'getinfo': return [
      cmt('── Bitcoin Node Summary ─────────────────────────'),
      key('node version             :', SERVER_SPECS.bitcoind),
      key('uptime                   :', SERVER_SPECS.uptime),
      key('network                  :', 'mainnet'),
      key('user                     :', USERNAME),
      key('blocks synced            :', `${blocksNow.toLocaleString()} (${syncPct.toFixed(2)}%)`),
      key('peers connected          :', String(SERVER_SPECS.peers)),
      key('mempool txs              :', '18,432'),
      key('storage used             :', `${stor.usedGB} GB / ${STORAGE_TOTAL_GB} GB`),
      key('storage free             :', `${stor.freeGB} GB`),
      key('wallet loaded            :', 'yes'),
      key('rpc port                 :', '8332'),
      key('p2p port                 :', '8333'),
    ]

    case 'getspecs': return [
      cmt('── Hardware Specifications ──────────────────────'),
      key('CPU                      :', SERVER_SPECS.cpu),
      key('RAM                      :', SERVER_SPECS.ram),
      key('Storage (total)          :', `${STORAGE_TOTAL_GB} GB NVMe SSD`),
      key('Storage (used)           :', `${stor.usedGB} GB  (${stor.utilPct}%)`),
      key('Storage (free)           :', `${stor.freeGB} GB`),
      key('OS                       :', SERVER_SPECS.os),
      key('Network                  :', SERVER_SPECS.network),
      key('dbcache                  :', '4096 MB'),
      key('par (threads)            :', '20'),
      key('maxconnections           :', '125'),
    ]

    case 'createrawtx': {
      const dest   = args[0] || 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
      const amt    = parseFloat(args[1]) || 0.001
      const change = 'bc1q' + rand16(38)
      return [
        cmt('── Create Raw Transaction ───────────────────────'),
        info('Building transaction inputs...'),
        key('input[0] txid           :', FAKE_UTXOS[0].txid),
        key('input[0] vout           :', '0'),
        key('input[0] value          :', `${FAKE_UTXOS[0].amount} BTC`),
        info('Building outputs...'),
        key('output[0] address       :', dest),
        key('output[0] value         :', `${amt.toFixed(8)} BTC`),
        key('output[1] change        :', change),
        key('output[1] value         :', `${(FAKE_UTXOS[0].amount - amt - 0.0001).toFixed(8)} BTC`),
        key('fee                     :', '0.00010000 BTC  (22 sat/vB)'),
        key('vsize                   :', '141 vbytes'),
        ok('Raw TX Hex:'),
        hex(`0200000001${FAKE_UTXOS[0].txid.slice(0, 48)}...${rand16(80)}`),
        ok(`Transaction ID: ${rand16(64)}`),
        cmt("Use 'sendrawtx <hex>' to broadcast."),
      ]
    }

    case 'fetchutxo': {
      const addr     = args[0] || 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
      const matching = FAKE_UTXOS.filter(u => !args[0] || u.address.startsWith(addr.slice(0, 10)))
      const total    = matching.reduce((s, u) => s + u.amount, 0)
      return [
        cmt(`── UTXOs for ${addr.slice(0, 20)}... ──`),
        ...matching.flatMap((u, i) => [
          info(`UTXO [${i}]`),
          key('  txid                 :', u.txid),
          key('  vout                 :', String(u.vout)),
          key('  amount               :', `${u.amount} BTC`),
          key('  confirmations        :', String(u.confs)),
          key('  spendable            :', 'true'),
        ]),
        cmt('─────────────────────────────────────────────────'),
        ok(`Total: ${total.toFixed(8)} BTC  (${matching.length} UTXOs)`),
      ]
    }

    case 'addrlookup': {
      const addr    = args[0] || 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
      const balance = randF(0.1, 2).toFixed(8)
      const txCount = randInt(10, 200)
      const addrType = addr.startsWith('bc1q') ? 'P2WPKH (native segwit)'
                     : addr.startsWith('bc1p') ? 'P2TR (taproot)' : 'P2PKH (legacy)'
      return [
        cmt('── Address Lookup ───────────────────────────────'),
        key('address                  :', addr),
        key('type                     :', addrType),
        key('confirmed balance        :', `${balance} BTC`),
        key('unconfirmed balance      :', '0.00000000 BTC'),
        key('total received           :', `${(parseFloat(balance) + randF(0, 5)).toFixed(8)} BTC`),
        key('total sent               :', `${randF(0, 4).toFixed(8)} BTC`),
        key('tx count                 :', String(txCount)),
        cmt('Recent transactions:'),
        ...Array.from({ length: 4 }, (_, i) =>
          key(`  tx[${i}]                 :`, `${rand16(16)}...  ${Math.random() > .5 ? '+' : '-'}${randF(0, .5).toFixed(8)} BTC  (${randInt(1, 1000)} confs)`)
        ),
      ]
    }

    case 'decodetx': {
      const h = args[0] || rand16(300)
      return [
        cmt('── Decoded Transaction ──────────────────────────'),
        key('txid                     :', rand16(64)),
        key('version                  :', '2'),
        key('locktime                 :', String(blocksNow)),
        key('size                     :', `${Math.floor(h.length / 2)} bytes`),
        key('vsize                    :', `${Math.floor(h.length / 4)} vbytes`),
        key('weight                   :', `${h.length} WU`),
        info('vin[0]:'),
        key('  txid                 :', rand16(64)),
        key('  vout                 :', '0'),
        key('  witness              :', `[${rand16(64)} ${rand16(66)}]`),
        key('  sequence             :', '4294967293'),
        info('vout[0]:'),
        key('  value               :', `${randF(0.001, 0.5).toFixed(8)} BTC`),
        key('  scriptPubKey type   :', 'witness_v0_keyhash'),
        key('  address             :', 'bc1q' + rand16(38)),
      ]
    }

    case 'sendrawtx': {
      if (Math.random() > 0.15) {
        return [
          ok('Transaction accepted by mempool'),
          key('txid                     :', rand16(64)),
          key('vsize                    :', `${randInt(100, 300)} vbytes`),
          key('fee                      :', `${randF(0.00001, 0.001).toFixed(8)} BTC`),
          ok(`Broadcast to ${SERVER_SPECS.peers} peers.`),
        ]
      }
      return [
        err('error: Transaction rejected'),
        err('reason: insufficient fee — min relay fee not met'),
        cmt('Tip: Use RBF or increase fee rate.'),
      ]
    }

    case 'getblockhash': {
      const h = parseInt(args[0])
      if (isNaN(h)) return [err('error: invalid block height')]
      return [res(rand16(64))]
    }

    case 'getblock': {
      const hash = args[0] || rand16(64)
      return [
        cmt('── Block Details ────────────────────────────────'),
        key('hash                     :', hash),
        key('confirmations            :', String(randInt(1, 1000))),
        key('height                   :', (blocksNow - randInt(0, 100)).toLocaleString()),
        key('version                  :', '0x20800004'),
        key('merkleroot               :', rand16(64)),
        key('time                     :', String(Math.floor(Date.now() / 1000 - randInt(0, 86400)))),
        key('nonce                    :', String(randInt(0, 4e9))),
        key('bits                     :', '17033a4d'),
        key('difficulty               :', '83148355189239.4'),
        key('ntx                      :', String(randInt(500, 3500))),
        key('size                     :', `${randInt(200, 1000)} KB`),
        key('weight                   :', `${randF(0.5, 4).toFixed(2)} MWU`),
      ]
    }

    // ── Session commands ──────────────────────────────────────────────────
    case 'whoami': {
      const s = getCurrentSession()
      return [
        cmt('── Current User ─────────────────────────────────'),
        key('user                     :', USERNAME),
        key('hostname                 :', 'bitcoin-node-live'),
        key('shell                    :', '/bin/btc-terminal'),
        key('login time               :', s ? fmtDT(s.loginTs) : '--'),
        key('session id               :', s ? String(s.id) : '--'),
        key('commands this session    :', s ? String(s.commands.length) : '0'),
        key('current time             :', fmtDT(Date.now())),
      ]
    }

    case 'lastlogin': {
      const arr = loadSessions()
      if (!arr.length) return [wrn('No previous login records found. (First session saved on exit.)')]
      const last = arr[arr.length - 1]
      const dur  = last.logoutTs ? Math.round((last.logoutTs - last.loginTs) / 1000) : null
      return [
        cmt('── Last Login Record ────────────────────────────'),
        key('login                    :', fmtDT(last.loginTs)),
        key('logout                   :', last.logoutTs ? fmtDT(last.logoutTs) : 'no logout recorded'),
        key('duration                 :', dur ? `${Math.floor(dur / 60)}m ${dur % 60}s` : '--'),
        key('commands issued          :', String(last.commands.length)),
        key('sync % at login          :', `${last.syncPctAtLogin}%`),
        key('storage used at login    :', last.storageAtLogin ? `${last.storageAtLogin.usedGB} GB` : '--'),
        key('total sessions on record :', String(arr.length)),
      ]
    }

    case 'sessioninfo': {
      const s = getCurrentSession()
      if (!s) return [err('error: no active session found')]
      const el   = Math.round((Date.now() - s.loginTs) / 1000)
      const stor2 = calcStorage(syncPct)
      return [
        cmt('── Active Session ───────────────────────────────'),
        key('session id               :', String(s.id)),
        key('user                     :', USERNAME),
        key('login time               :', fmtDT(s.loginTs)),
        key('elapsed                  :', `${Math.floor(el / 3600)}h ${Math.floor((el % 3600) / 60)}m ${el % 60}s`),
        key('commands issued          :', String(s.commands.length)),
        key('sync at login            :', `${s.syncPctAtLogin}%`),
        key('current sync             :', `${syncPct.toFixed(2)}%`),
        key('storage at login         :', `${s.storageAtLogin.usedGB} GB used, ${s.storageAtLogin.freeGB} GB free`),
        key('storage now              :', `${stor2.usedGB} GB used, ${stor2.freeGB} GB free`),
        cmt('View full log in the SESSION LOG tab.'),
      ]
    }

    default:
      return [err(`error: Unknown command '${c}'. Type 'help' for list.`)]
  }
}

import { BLOCKCHAIN_SIZE_GB, STORAGE_TOTAL_GB, MB_PER_SEC } from './constants.js'

// ── Time ──────────────────────────────────────────────────────────────────
export const ts = () => new Date().toTimeString().slice(0, 8)

export const fmtDT = (ts) => {
  if (!ts) return '--'
  const d = new Date(ts)
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
       + ' ' + d.toTimeString().slice(0, 8)
}

// ── Random ────────────────────────────────────────────────────────────────
export const rand16  = (n = 64) => Array.from({ length: n }, () => (Math.random() * 16 | 0).toString(16)).join('')
export const randInt = (a, b)   => Math.floor(Math.random() * (b - a) + a)
export const randF   = (a, b)   => Math.random() * (b - a) + a

// ── Sync calculations ─────────────────────────────────────────────────────
export function calcStorage(pct) {
  const usedGB  = parseFloat((BLOCKCHAIN_SIZE_GB * pct / 100).toFixed(1))
  const freeGB  = parseFloat((STORAGE_TOTAL_GB - usedGB).toFixed(1))
  const utilPct = parseFloat((usedGB / STORAGE_TOTAL_GB * 100).toFixed(1))
  return { usedGB, freeGB, utilPct }
}

export function calcETA(pct) {
  const remGB   = BLOCKCHAIN_SIZE_GB * (1 - pct / 100)
  const remSecs = (remGB * 1024) / MB_PER_SEC
  const remH    = Math.floor(remSecs / 3600)
  const remM    = Math.floor((remSecs % 3600) / 60)
  const remHDec = (remSecs / 3600).toFixed(1)
  return { remH, remM, remHDec, remGB: remGB.toFixed(1) }
}

// ── Mempool tx generator ──────────────────────────────────────────────────
export function fakeMemTx() {
  return {
    txid:    (Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2)).padEnd(64, '0').slice(0, 64),
    size:    randInt(100, 900),
    vsize:   randInt(80, 450),
    fee:     randF(0.00001, 0.002).toFixed(8),
    feeRate: randF(1, 80).toFixed(2),
    time:    Date.now() - randInt(0, 600_000),
  }
}

export const feeClass = (rate) => {
  const v = parseFloat(rate)
  if (v > 30) return 'fee-high'
  if (v > 10) return 'fee-med'
  return 'fee-low'
}

import { SESSION_KEY, CURRENT_KEY } from './constants.js'
import { calcStorage } from './helpers.js'

export function loadSessions() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || '[]') }
  catch { return [] }
}

export function saveSessions(arr) {
  try { localStorage.setItem(SESSION_KEY, JSON.stringify(arr.slice(-50))) } catch {}
}

export function getCurrentSession() {
  try { return JSON.parse(localStorage.getItem(CURRENT_KEY) || 'null') }
  catch { return null }
}

export function saveCurrentSession(s) {
  try { localStorage.setItem(CURRENT_KEY, JSON.stringify(s)) } catch {}
}

export function recordLogin(syncPct) {
  const now      = Date.now()
  const sessions = loadSessions()
  const prev     = sessions.length ? sessions[sessions.length - 1] : null
  const prevTs   = prev ? prev.loginTs : null
  const stor     = calcStorage(syncPct)

  const session = {
    id: now, loginTs: now, logoutTs: null,
    commands: [],
    syncPctAtLogin: syncPct,
    storageAtLogin: stor,
  }
  saveCurrentSession(session)
  return { prevTs, now }
}

export function logCommand(cmd) {
  const s = getCurrentSession()
  if (!s) return
  s.commands.push({ ts: Date.now(), cmd })
  saveCurrentSession(s)
}

export function finaliseSession() {
  const s = getCurrentSession()
  if (!s) return
  s.logoutTs = Date.now()
  const arr = loadSessions()
  arr.push(s)
  saveSessions(arr)
  try { localStorage.removeItem(CURRENT_KEY) } catch {}
}

export function clearAllSessions() {
  try { localStorage.removeItem(SESSION_KEY) } catch {}
}

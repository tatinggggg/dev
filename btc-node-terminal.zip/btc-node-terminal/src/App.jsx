import { useState, useEffect, useCallback, useRef } from 'react'
import styles from './App.module.css'

import TopBar         from './components/TopBar.jsx'
import Sidebar        from './components/Sidebar.jsx'
import TerminalOutput from './components/TerminalOutput.jsx'
import CommandInput   from './components/CommandInput.jsx'
import MempoolTab     from './components/MempoolTab.jsx'
import PeersTab       from './components/PeersTab.jsx'
import SpecsTab       from './components/SpecsTab.jsx'
import SessionLogTab  from './components/SessionLogTab.jsx'

import { useSync }     from './hooks/useSync.js'
import { useClock }    from './hooks/useClock.js'
import { useTerminal } from './hooks/useTerminal.js'

import { recordLogin, finaliseSession } from './utils/session.js'
import { TABS } from './utils/constants.js'

const TAB_LABELS = {
  terminal:   'TERMINAL',
  mempool:    'MEMPOOL',
  peers:      'PEERS',
  specs:      'SPECS',
  sessionlog: 'SESSION LOG',
}

export default function App() {
  const { syncPct, blocksNow, storage, eta } = useSync()
  const clock                                 = useClock()

  const [activeTab,    setActiveTab]    = useState('terminal')
  const [loginInfo,    setLoginInfo]    = useState(null)
  const [focusTrigger, setFocusTrigger] = useState(0)

  const {
    lines, rpcLog, input, suggestions, selSug,
    handleInput, handleKey, runCommand, boot,
  } = useTerminal(syncPct, blocksNow)

  // Record login on mount, finalise on unmount
  useEffect(() => {
    const info = recordLogin(syncPct)
    setLoginInfo(info)
    boot(info)
    window.addEventListener('beforeunload', finaliseSession)
    return () => window.removeEventListener('beforeunload', finaliseSession)
  }, []) // intentionally run once

  const handleTabClick = useCallback((tab) => {
    setActiveTab(tab)
    if (tab === 'terminal') setFocusTrigger(n => n + 1)
  }, [])

  const handleRootClick = useCallback(() => {
    if (activeTab === 'terminal') setFocusTrigger(n => n + 1)
  }, [activeTab])

  const handleSugClick = useCallback((s) => {
    handleInput(s)
    // After selecting, focus is maintained by CommandInput
  }, [handleInput])

  const handleExec = useCallback(() => {
    runCommand(input)
  }, [runCommand, input])

  return (
    <div className={styles.root} onClick={handleRootClick}>
      <TopBar syncPct={syncPct} clock={clock} />

      <div className={styles.layout}>
        <Sidebar
          syncPct={syncPct}
          storage={storage}
          eta={eta}
          blocksNow={blocksNow}
          rpcLog={rpcLog}
          loginInfo={loginInfo}
        />

        <div className={styles.panel}>
          {/* Tab bar */}
          <div className={styles.tabBar}>
            {TABS.map(tab => (
              <button
                key={tab}
                className={`${styles.tab} ${activeTab === tab ? styles.tabActive : ''}`}
                onClick={e => { e.stopPropagation(); handleTabClick(tab) }}
              >
                {TAB_LABELS[tab]}
              </button>
            ))}
          </div>

          {/* Tab contents */}
          <div className={styles.content}>
            {activeTab === 'terminal' && (
              <TerminalOutput lines={lines} />
            )}
            {activeTab === 'mempool' && (
              <MempoolTab active={activeTab === 'mempool'} />
            )}
            {activeTab === 'peers' && (
              <PeersTab blocksNow={blocksNow} />
            )}
            {activeTab === 'specs' && (
              <SpecsTab />
            )}
            {activeTab === 'sessionlog' && (
              <SessionLogTab active={activeTab === 'sessionlog'} />
            )}
          </div>

          {/* Input — only visible on terminal tab */}
          {activeTab === 'terminal' && (
            <CommandInput
              input={input}
              onInput={handleInput}
              onKey={handleKey}
              onExec={handleExec}
              suggestions={suggestions}
              selSug={selSug}
              onSugClick={handleSugClick}
              focusTrigger={focusTrigger}
            />
          )}
        </div>
      </div>
    </div>
  )
}

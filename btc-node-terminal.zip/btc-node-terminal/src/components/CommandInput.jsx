import { useRef, useEffect } from 'react'
import styles from './CommandInput.module.css'
import { USERNAME } from '../utils/constants.js'

export default function CommandInput({
  input, onInput, onKey, onExec, suggestions, selSug, onSugClick, focusTrigger
}) {
  const inputRef = useRef(null)

  useEffect(() => { inputRef.current?.focus() }, [focusTrigger])

  return (
    <div className={styles.wrap}>
      {suggestions.length > 0 && (
        <div className={styles.sugBox}>
          {suggestions.slice(0, 10).map((s, i) => (
            <div
              key={s}
              className={`${styles.sugItem} ${i === selSug ? styles.sel : ''}`}
              onMouseDown={e => { e.preventDefault(); onSugClick(s) }}
            >
              {s}
            </div>
          ))}
        </div>
      )}

      <div className={styles.row}>
        <span className={styles.prompt}>
          <span className={styles.pu}>{USERNAME}</span>
          <span className={styles.ps}>:</span>
          <span className={styles.pd}>~$</span>
        </span>
        <input
          ref={inputRef}
          className={styles.input}
          value={input}
          onChange={e => onInput(e.target.value)}
          onKeyDown={onKey}
          placeholder="type command or 'help'..."
          autoComplete="off"
          autoCorrect="off"
          spellCheck="false"
        />
        <button className={styles.btn} onClick={onExec}>EXEC</button>
      </div>
    </div>
  )
}

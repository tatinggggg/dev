import styles from './Tabs.module.css'
import {
  BLOCKCHAIN_SIZE_GB, STORAGE_TOTAL_GB, CPU_SPEED_GHZ, MB_PER_SEC,
  SYNCED_PERCENT_INIT, SERVER_SPECS
} from '../utils/constants.js'
import { calcStorage, calcETA } from '../utils/helpers.js'

const stor = calcStorage(SYNCED_PERCENT_INIT)
const eta  = calcETA(SYNCED_PERCENT_INIT)

const SECTIONS = [
  { label: '── Hardware', rows: [
    ['CPU',             SERVER_SPECS.cpu],
    ['RAM',             SERVER_SPECS.ram],
    ['Storage (total)', `${STORAGE_TOTAL_GB} GB NVMe SSD`],
    ['Storage (used)',  `${stor.usedGB} GB  (${stor.utilPct}%)`],
    ['Storage (free)',  `${stor.freeGB} GB`],
    ['Network',         SERVER_SPECS.network],
  ]},
  { label: '── Software', rows: [
    ['OS',           SERVER_SPECS.os],
    ['Bitcoin Core', SERVER_SPECS.bitcoind],
    ['Protocol',     '70016'],
    ['dbcache',      '4096 MB'],
  ]},
  { label: '── Node Config', rows: [
    ['txindex',        '1'],
    ['server',         '1'],
    ['rpcport',        '8332'],
    ['port',           '8333'],
    ['maxconnections', '125'],
    ['par',            '20 (all threads)'],
    ['prune',          '0 (full node)'],
    ['listen',         '1'],
  ]},
  { label: '── ETA & Sync Math', rows: [
    ['Chain size',       `${BLOCKCHAIN_SIZE_GB} GB`],
    ['Synced at boot',   `${stor.usedGB} GB  (${SYNCED_PERCENT_INIT}%)`],
    ['Remaining at boot',`${eta.remGB} GB`],
    ['CPU speed',        `${CPU_SPEED_GHZ} GHz`],
    ['Throughput formula','CPU GHz × 2.1 = MB/s'],
    ['Est. throughput',  `${MB_PER_SEC.toFixed(2)} MB/s`],
    ['ETA formula',      '(remGB × 1024) / throughput / 3600'],
    ['ETA at boot',      `~${eta.remH}h ${eta.remM}m  (~${eta.remHDec} hours)`],
  ]},
]

export default function SpecsTab() {
  return (
    <div className={styles.tabContent}>
      {SECTIONS.map(sec => (
        <div key={sec.label} className={styles.specsSection}>
          <div className={styles.specsTitle}>{sec.label}</div>
          {sec.rows.map(([k, v]) => (
            <div key={k} className={styles.specRow}>
              <span className={styles.specK}>{k}</span>
              <span className={styles.specV}>{v}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

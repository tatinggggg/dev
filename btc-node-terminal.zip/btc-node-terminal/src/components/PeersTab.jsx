import { useMemo } from 'react'
import styles from './Tabs.module.css'
import { randInt } from '../utils/helpers.js'
import { SERVER_SPECS } from '../utils/constants.js'

const COUNTRIES = ['US','DE','NL','FR','JP','SG','CA','GB','AU','CH','BR','KR']
const IPS       = [104,198,45,88,134,23,67,172,52,91,55,77]

export default function PeersTab({ blocksNow }) {
  const peers = useMemo(() => (
    Array.from({ length: 16 }, (_, i) => ({
      id:      i,
      inbound: i % 3 === 0,
      ip:      `${IPS[i % 12]}.${randInt(1,254)}.${randInt(1,254)}.${randInt(1,254)}`,
      country: COUNTRIES[i % 12],
      ping:    randInt(8, 100),
      blk:     blocksNow - randInt(0, 200),
    }))
  ), [])

  return (
    <div className={styles.tabContent}>
      <div className={styles.hdr}>
        <span className={styles.greenDot}>●</span> {SERVER_SPECS.inbound} inbound &nbsp;
        <span className={styles.blueDot}>●</span>  {SERVER_SPECS.outbound} outbound
      </div>
      <div className={styles.peersGrid}>
        {peers.map(p => (
          <div key={p.id} className={styles.peerCard}>
            <div className={`${styles.peerDot} ${p.inbound ? '' : styles.peerDotOut}`} />
            <div className={styles.peerAddr}>{p.ip}:8333</div>
            <div className={styles.peerMeta}>
              {p.country} · v70016 · {p.ping}ms · blk {p.blk.toLocaleString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

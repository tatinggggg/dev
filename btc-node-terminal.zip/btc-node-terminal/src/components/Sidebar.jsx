import styles from './Sidebar.module.css'
import { SERVER_SPECS } from '../utils/constants.js'
import { fmtDT } from '../utils/helpers.js'

export default function Sidebar({ syncPct, storage, eta, blocksNow, rpcLog, loginInfo }) {
  return (
    <aside className={styles.sidebar}>

      {/* ── Sync Progress ── */}
      <div className={styles.section}>
        <div className={styles.label}>Blockchain Sync</div>
      </div>
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <span className={styles.bigPct}>{syncPct.toFixed(1)}%</span>
          <span className={styles.cardLbl}>IBD PROGRESS</span>
        </div>
        <div className={styles.track}>
          <div className={styles.fillAmber} style={{ width: `${syncPct.toFixed(3)}%` }} />
        </div>
        <div className={styles.statsGrid}>
          <Stat label="Synced"    value={`${storage.usedGB.toFixed(1)} GB`} />
          <Stat label="Total"     value="620 GB" />
          <Stat label="Remaining" value={`${eta.remH}h ${eta.remM}m`} />
          <Stat label="Speed"     value={`${(3.4 * 2.1).toFixed(1)} MB/s`} />
          <Stat label="Blocks"    value={blocksNow.toLocaleString()} />
          <Stat label="Height"    value="834,217" />
        </div>
      </div>

      {/* ── Storage ── */}
      <div className={styles.section} style={{ paddingBottom: 0 }}>
        <div className={styles.label}>Storage (1 TB NVMe)</div>
      </div>
      <div className={styles.card} style={{ marginTop: 0 }}>
        <div className={styles.cardHeader}>
          <span className={styles.bigCyan}>{storage.usedGB.toFixed(1)} GB</span>
          <span className={styles.cardLbl}>USED</span>
        </div>
        <div className={styles.track}>
          <div className={styles.fillCyan} style={{ width: `${storage.utilPct}%` }} />
        </div>
        <div className={styles.statsGrid}>
          <Stat label="Used"  value={`${storage.usedGB.toFixed(1)} GB`} />
          <Stat label="Free"  value={`${storage.freeGB.toFixed(1)} GB`} />
          <Stat label="Total" value="1,000 GB" />
          <Stat label="Util." value={`${storage.utilPct}%`} />
        </div>
      </div>

      {/* ── Metrics ── */}
      <div className={styles.section} style={{ paddingBottom: 0 }}>
        <div className={styles.label}>Live Metrics</div>
      </div>
      <div className={styles.metricsGrid}>
        {[
          { val: SERVER_SPECS.peers,    sub: 'Peers'    },
          { val: '18.4K',              sub: 'Mempool'  },
          { val: '85%',                sub: 'CPU'      },
          { val: '6.4 MB/s',           sub: 'Disk I/O' },
          { val: SERVER_SPECS.inbound,  sub: 'Inbound'  },
          { val: SERVER_SPECS.outbound, sub: 'Outbound' },
        ].map(m => (
          <div key={m.sub} className={styles.metricCard}>
            <div className={styles.metricVal}>{m.val}</div>
            <div className={styles.metricSub}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* ── RPC Log ── */}
      <div className={styles.section} style={{ paddingBottom: 4 }}>
        <div className={styles.label}>RPC Call Log</div>
      </div>
      <div className={styles.rpcLog}>
        {rpcLog.length === 0
          ? <div className={styles.rpcEmpty}>No calls yet</div>
          : rpcLog.map((r, i) => (
            <div key={i} className={styles.rpcItem}>
              <span className={styles.rpcTs}>[{r.ts}] </span>
              <span className={styles.rpcCmd}>{r.cmd}</span>
            </div>
          ))
        }
      </div>

      {/* ── Session ── */}
      <div className={styles.section}>
        <div className={styles.label}>Session</div>
        <div className={styles.sessionInfo}>
          <div style={{ color: 'var(--text2)' }}>bitcoin@live</div>
          <div className={styles.sv}>Login: {loginInfo?.now ? fmtDT(loginInfo.now) : '--'}</div>
          <div className={styles.dim}>Prev: {loginInfo?.prevTs ? fmtDT(loginInfo.prevTs) : 'no record'}</div>
        </div>
      </div>

    </aside>
  )
}

function Stat({ label, value }) {
  return (
    <div className={styles.stat}>
      {label}<span>{value}</span>
    </div>
  )
}

import { useState, useEffect, useCallback } from 'react'
import styles from './Tabs.module.css'
import { loadSessions, getCurrentSession, clearAllSessions } from '../utils/session.js'
import { fmtDT } from '../utils/helpers.js'

export default function SessionLogTab({ active }) {
  const [sessions, setSessions]     = useState([])
  const [current,  setCurrent]      = useState(null)
  const [elapsed,  setElapsed]      = useState(0)

  const refresh = useCallback(() => {
    setSessions(loadSessions())
    setCurrent(getCurrentSession())
  }, [])

  useEffect(() => { if (active) refresh() }, [active, refresh])

  useEffect(() => {
    const id = setInterval(() => {
      const cur = getCurrentSession()
      if (cur) setElapsed(Math.round((Date.now() - cur.loginTs) / 1000))
    }, 1000)
    return () => clearInterval(id)
  }, [])

  function handleClear() {
    if (window.confirm('Delete all saved session logs? This cannot be undone.')) {
      clearAllSessions()
      refresh()
    }
  }

  return (
    <div className={styles.tabContent}>
      <div className={styles.sessionHeader}>
        <div className={styles.specsTitle}>── User Session Log ────────────────────────────</div>
        <button className={styles.clearBtn} onClick={handleClear}>CLEAR ALL</button>
      </div>

      {/* Current session */}
      {current && (
        <div className={`${styles.sessionEntry} ${styles.sessionActive}`}>
          <div className={styles.sessionHdr}>
            <span className={styles.seActive}>● CURRENT SESSION</span>
            <span className={styles.seTs}>{fmtDT(current.loginTs)}</span>
            <span className={styles.seDur}>
              {Math.floor(elapsed / 60)}m {elapsed % 60}s · {current.commands.length} cmd(s)
            </span>
          </div>
          <div className={styles.sessionCmds}>
            {current.commands.length === 0
              ? <div className={styles.noCmds}>No commands issued yet</div>
              : [...current.commands].reverse().map((c, i) => (
                <div key={i} className={styles.cmdRow}>
                  <span className={styles.cmdTs}>[{fmtDT(c.ts).slice(12)}]</span>
                  <span className={styles.cmdText}>{c.cmd}</span>
                </div>
              ))
            }
          </div>
        </div>
      )}

      {/* Past sessions */}
      {sessions.length === 0 && !current && (
        <div className={styles.noLogs}>
          No session logs yet. Logs are saved to localStorage on tab/window close.
          Come back after reloading the page to see previous sessions.
        </div>
      )}

      {[...sessions].reverse().map((sess, i) => {
        const dur = sess.logoutTs
          ? Math.round((sess.logoutTs - sess.loginTs) / 1000)
          : null
        return (
          <div key={sess.id} className={styles.sessionEntry}>
            <div className={styles.sessionHdr}>
              <span className={styles.seIdx}>#{sessions.length - i}</span>
              <span className={styles.seTs}>{fmtDT(sess.loginTs)}</span>
              <span className={styles.seDur}>
                {dur ? `${Math.floor(dur / 60)}m ${dur % 60}s` : '--'} · {sess.commands.length} cmd(s) · sync: {sess.syncPctAtLogin}%
              </span>
            </div>
            <div className={styles.sessionCmds}>
              {sess.commands.length === 0
                ? <div className={styles.noCmds}>No commands recorded</div>
                : [...sess.commands].reverse().slice(0, 30).map((c, j) => (
                  <div key={j} className={styles.cmdRow}>
                    <span className={styles.cmdTs}>[{fmtDT(c.ts).slice(12)}]</span>
                    <span className={styles.cmdText}>{c.cmd}</span>
                  </div>
                ))
              }
              {sess.commands.length > 30 && (
                <div className={styles.more}>… +{sess.commands.length - 30} more</div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

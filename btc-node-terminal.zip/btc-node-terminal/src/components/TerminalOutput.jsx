import { useEffect, useRef } from 'react'
import styles from './TerminalOutput.module.css'
import { USERNAME } from '../utils/constants.js'

const LINE_MAP = {
  comment: styles.comment,
  info:    styles.info,
  ok:      styles.ok,
  error:   styles.error,
  warn:    styles.warn,
  result:  styles.result,
  txid:    styles.txid,
  hex:     styles.hex,
  cmd:     styles.cmd,
  session: styles.session,
}

function Line({ line }) {
  if (line.t === 'spacer') return <div className={styles.spacer} />

  if (line.t === 'prompt') return (
    <div className={`${styles.line} ${styles.prompt}`}>
      <span className={styles.pUser}>{USERNAME}</span>
      <span className={styles.pSep}>:</span>
      <span className={styles.pDir}>~$</span>
      <span className={styles.pCmd}>{line.v}</span>
    </div>
  )

  if (line.t === 'key') return (
    <div className={`${styles.line} ${styles.keyLine}`}>
      <span className={styles.kk}>{line.v}</span>
      <span className={styles.kv}>{line.s}</span>
    </div>
  )

  return (
    <div className={`${styles.line} ${LINE_MAP[line.t] || ''}`}>
      {line.v}
    </div>
  )
}

export default function TerminalOutput({ lines }) {
  const ref = useRef(null)

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight
  }, [lines])

  return (
    <div className={styles.output} ref={ref}>
      {lines.map((line, i) => <Line key={i} line={line} />)}
    </div>
  )
}

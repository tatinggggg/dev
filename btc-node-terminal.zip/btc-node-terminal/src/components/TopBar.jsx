import styles from './TopBar.module.css'
import { USERNAME } from '../utils/constants.js'

export default function TopBar({ syncPct, clock }) {
  return (
    <header className={styles.topbar}>
      <div className={styles.brand}>
        <div className={styles.btcIcon}>₿</div>
        <div>
          <div className={styles.title}>BITCOIN FULL NODE</div>
          <div className={styles.sub}>
            {USERNAME}:~  ·  mainnet  ·  Bitcoin Core v26.0.0
          </div>
        </div>
      </div>
      <div className={styles.right}>
        <span className={`${styles.pill} ${styles.pillIbd}`}>
          IBD {syncPct.toFixed(1)}%
        </span>
        <span className={`${styles.pill} ${styles.pillOnline}`}>
          ● ONLINE
        </span>
        <span className={styles.clock}>{clock}</span>
      </div>
    </header>
  )
}

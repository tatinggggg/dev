import { useState, useEffect } from 'react'
import styles from './Tabs.module.css'
import { fakeMemTx, feeClass } from '../utils/helpers.js'

function makeMempoolTxs(n = 12) {
  return Array.from({ length: n }, () => fakeMemTx())
}

export default function MempoolTab({ active }) {
  const [txs, setTxs] = useState(() => makeMempoolTxs())

  useEffect(() => {
    if (!active) return
    const id = setInterval(() => {
      setTxs(old => [fakeMemTx(), ...old.slice(0, 11)])
    }, 3000)
    return () => clearInterval(id)
  }, [active])

  return (
    <div className={styles.tabContent}>
      <div className={styles.hdr}>
        Live mempool — <span className={styles.amber}>18,432</span> txs · updating every 3s
      </div>
      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>TXID</th><th>SIZE</th><th>VSIZE</th><th>FEE (BTC)</th><th>SAT/VB</th><th>AGO</th>
            </tr>
          </thead>
          <tbody>
            {txs.map((tx, i) => {
              const ago = Math.floor((Date.now() - tx.time) / 1000)
              return (
                <tr key={i}>
                  <td className={styles.txidCell}>{tx.txid.slice(0, 26)}…</td>
                  <td>{tx.size}</td>
                  <td>{tx.vsize}</td>
                  <td>{tx.fee}</td>
                  <td className={styles[feeClass(tx.feeRate)]}>{tx.feeRate}</td>
                  <td className={styles.dimCell}>{ago}s</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

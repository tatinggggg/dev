# ₿ Bitcoin Full Node Terminal

A fully interactive Bitcoin full node sync terminal built with **React + Vite**.

## Features

- 📡 **Live IBD progress** — 42% synced, dynamic ETA calculated from CPU throughput
- 💾 **Storage tracker** — Used / Free / Utilization updated in real-time
- ⌨️ **20+ RPC commands** — `help`, `syncstatus`, `getblockchaininfo`, `createrawtx`, `fetchutxo`, `addrlookup`, `sendrawtx`, and more
- 🔁 **TAB autocomplete** + **↑/↓ command history**
- 📊 **Mempool tab** — live table churning every 3s
- 🌐 **Peers tab** — 16 connected nodes with ping/block info
- 🔧 **Specs tab** — hardware, node config, ETA formula breakdown
- 🗂️ **Session Log tab** — login timestamps, command history stored in localStorage
- 👤 **Session commands**: `whoami`, `lastlogin`, `sessioninfo`
- 📱 **Mobile responsive** — sidebar hides on small screens, font/layout adapts

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server (opens at http://localhost:3000)
npm run dev

# 3. Build for production
npm run build

# 4. Preview production build
npm run preview
```

## Project Structure

```
btc-node-terminal/
├── index.html
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.module.css
    ├── styles/
    │   └── global.css
    ├── utils/
    │   ├── constants.js   — all shared constants
    │   ├── helpers.js     — time, random, storage/ETA calculators
    │   ├── rpc.js         — all RPC command handlers
    │   └── session.js     — localStorage session management
    ├── hooks/
    │   ├── useSync.js     — live sync % and block height state
    │   ├── useClock.js    — live clock
    │   └── useTerminal.js — terminal state and command execution
    └── components/
        ├── TopBar.jsx / .module.css
        ├── Sidebar.jsx / .module.css
        ├── TerminalOutput.jsx / .module.css
        ├── CommandInput.jsx / .module.css
        ├── MempoolTab.jsx
        ├── PeersTab.jsx
        ├── SpecsTab.jsx
        ├── SessionLogTab.jsx
        └── Tabs.module.css
```

## Terminal Commands

| Command | Description |
|---------|-------------|
| `help` | Full command list |
| `getblockchaininfo` | Chain state + live storage |
| `syncstatus` | IBD progress + dynamic ETA |
| `getspecs` | Hardware specifications |
| `getinfo` | Node summary |
| `getnetworkinfo` | Network & peer data |
| `getpeerinfo` | Connected peers detail |
| `getmempoolinfo` | Mempool stats |
| `getrawmempool` | Mempool txids |
| `syncmempool` | Force mempool sync |
| `createrawtx [addr] [amt]` | Build raw transaction |
| `fetchutxo <addr>` | Address UTXOs |
| `addrlookup <addr>` | Address info & history |
| `decodetx <hex>` | Decode raw tx |
| `sendrawtx <hex>` | Broadcast transaction |
| `whoami` | Current user + session |
| `lastlogin` | Previous login record |
| `sessioninfo` | Active session details |
| `clear` | Clear terminal |

## Stack

- [Vite](https://vitejs.dev/) — build tool
- [React 18](https://reactjs.org/) — UI
- CSS Modules — scoped styles
- localStorage — session persistence
- Google Fonts (JetBrains Mono)

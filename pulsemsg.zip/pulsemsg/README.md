# 📱 PulseMsg — SMS Notification Center

A full-stack SMS notification app powered by **Twilio**. Send real SMS messages with sender name, priority levels, and scheduling.

---

## 🚀 Quick Start (Local — Node.js)

### 1. Prerequisites
- Node.js 18+ → https://nodejs.org
- Twilio account → https://twilio.com (free trial available)

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment
```bash
cp .env.example .env
```
Open `.env` and fill in your Twilio credentials:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+15551234567
```

Get these from: https://console.twilio.com

### 4. Run the server
```bash
npm start
# or for auto-reload during development:
npm run dev
```

### 5. Open the app
Visit: **http://localhost:3000**

---

## ☁️ Deploy to Netlify (Free Hosting)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
gh repo create pulsemsg --public --push
```

### 2. Deploy on Netlify
1. Go to https://netlify.com → "Add new site" → "Import from Git"
2. Select your repo
3. Build settings are auto-detected from `netlify.toml`
4. Click **Deploy**

### 3. Add environment variables
In Netlify dashboard → Site Settings → Environment Variables, add:
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_PHONE_NUMBER`

> **Note:** Scheduled SMS (setTimeout) only works on the Node.js server, not Netlify Functions (which are stateless). For production scheduling on Netlify, use Twilio's built-in message scheduling API or a cron job service.

---

## 🔑 Getting Twilio Credentials

1. Sign up at https://twilio.com (free trial gives ~$15 credit)
2. Go to Console Dashboard → copy **Account SID** and **Auth Token**
3. Get a Twilio phone number: Console → Phone Numbers → Manage → Buy a number (~$1/month)
4. On free trial: you can only send to **verified numbers** (your own phone)
   - Verify at: Console → Verified Caller IDs

---

## 📁 Project Structure

```
pulsemsg/
├── server.js              # Express backend (local/VPS)
├── package.json
├── .env.example           # Environment variable template
├── netlify.toml           # Netlify deployment config
├── public/
│   └── index.html         # Frontend app
└── netlify/
    └── functions/
        ├── send-sms.js    # Serverless SMS endpoint
        └── health.js      # Health check endpoint
```

---

## ✨ Features

- **Sender Name** — shown in every SMS message
- **Country code picker** — 20+ countries
- **Priority levels** — Low / Normal / High / Critical
- **Schedule SMS** — set date, time, and timezone
- **Cancel scheduled** — cancel before it fires
- **Message log** — real-time status with Twilio SID
- **Health indicator** — shows if Twilio is connected
- **Mobile responsive** — works on all screen sizes

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/send-sms` | Send SMS immediately |
| POST | `/api/schedule-sms` | Schedule SMS for later |
| DELETE | `/api/schedule-sms/:jobId` | Cancel scheduled SMS |
| GET | `/api/health` | Check server + Twilio status |

---

## 🛠 Tech Stack

- **Backend:** Node.js, Express, Twilio SDK
- **Frontend:** Vanilla HTML/CSS/JS
- **SMS:** Twilio Programmable Messaging
- **Deploy:** Netlify (serverless) or any Node.js host

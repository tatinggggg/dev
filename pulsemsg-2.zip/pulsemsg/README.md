# 📱 PulseMsg — SMS Notification Center

A full-stack SMS notification app powered by **Twilio**. Send real SMS messages with sender name, priority levels, and scheduling — deployable locally, on Netlify, or on a DigitalOcean VPS Droplet.

---

## 📋 Table of Contents

- [Local Development](#-local-development)
- [Deploy to DigitalOcean VPS (Droplet)](#-deploy-to-digitalocean-vps-droplet) ⭐ Recommended for real SMS + scheduling
- [Deploy to Netlify (Free / Serverless)](#-deploy-to-netlify-free--serverless)
- [Getting Twilio Credentials](#-getting-twilio-credentials)
- [API Endpoints](#-api-endpoints)
- [Project Structure](#-project-structure)

---

## 💻 Local Development

### Prerequisites
- Node.js 18+ → https://nodejs.org
- Twilio account → https://twilio.com

```bash
# 1. Clone and install
git clone https://github.com/YOUR_USERNAME/pulsemsg.git
cd pulsemsg
npm install

# 2. Set up environment
cp .env.example .env
nano .env   # Fill in your Twilio credentials

# 3. Start
npm start
# Open http://localhost:3000
```

---

## 🌊 Deploy to DigitalOcean VPS (Droplet)

> ✅ **Best option** — supports real SMS, server-side scheduling, persistent process management, and HTTPS with your own domain.

### Step 1 — Create a Droplet

1. Log in to [DigitalOcean](https://cloud.digitalocean.com)
2. Click **Create → Droplets**
3. Choose:
   - **Image:** Ubuntu 24.04 LTS x64
   - **Plan:** Basic → Regular → **$6/month** (1 vCPU, 1GB RAM) — plenty for this app
   - **Datacenter:** Choose closest to your users
   - **Authentication:** SSH Key (recommended) or Password
4. Click **Create Droplet**
5. Note your Droplet's **IP address** (e.g. `167.99.10.123`)

---

### Step 2 — Connect to Your Droplet

```bash
ssh root@YOUR_DROPLET_IP
```

---

### Step 3 — Run the Setup Script

Copy and paste this entire block into your SSH terminal. It installs everything automatically:

```bash
#!/bin/bash

# Update system
apt update && apt upgrade -y

# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 (process manager — keeps app alive after reboot)
npm install -g pm2

# Install Nginx (reverse proxy — serves app on port 80/443)
apt install -y nginx

# Install Git
apt install -y git

# Verify installations
echo "Node: $(node -v)"
echo "NPM:  $(npm -v)"
echo "PM2:  $(pm2 -v)"
echo "Nginx: $(nginx -v)"
```

---

### Step 4 — Clone Your GitHub Repo

```bash
cd /var/www
git clone https://github.com/YOUR_USERNAME/pulsemsg.git
cd pulsemsg
npm install --production
```

---

### Step 5 — Configure Environment Variables

```bash
cp .env.example .env
nano .env
```

Fill in your Twilio credentials:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+15551234567
PORT=3000
```

Save and exit: `Ctrl+X` → `Y` → `Enter`

---

### Step 6 — Start App with PM2

```bash
# Start the app
pm2 start server.js --name pulsemsg

# Save PM2 process list (so it restarts on reboot)
pm2 save

# Enable PM2 to start on system boot
pm2 startup
# ↑ Copy and run the command it outputs

# Check status
pm2 status
pm2 logs pulsemsg
```

Your app is now running at `http://YOUR_DROPLET_IP:3000`

---

### Step 7 — Configure Nginx (Serve on Port 80)

```bash
nano /etc/nginx/sites-available/pulsemsg
```

Paste this config (replace `YOUR_DROPLET_IP` or your domain):

```nginx
server {
    listen 80;
    server_name YOUR_DROPLET_IP;   # or yourdomain.com

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable and restart Nginx:

```bash
# Enable the site
ln -s /etc/nginx/sites-available/pulsemsg /etc/nginx/sites-enabled/

# Remove default site
rm /etc/nginx/sites-enabled/default

# Test config
nginx -t

# Restart Nginx
systemctl restart nginx
systemctl enable nginx

# Open firewall ports
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw enable
```

Your app is now live at `http://YOUR_DROPLET_IP` (no port number needed!)

---

### Step 8 — Enable HTTPS with Free SSL (Optional but Recommended)

> Requires a domain name pointed to your Droplet IP. Update your domain's DNS A record to point to the IP.

```bash
# Install Certbot
apt install -y certbot python3-certbot-nginx

# Get free SSL certificate (replace with your domain)
certbot --nginx -d yourdomain.com

# Auto-renewal is set up automatically. Test it:
certbot renew --dry-run
```

Your app is now live at `https://yourdomain.com` 🔒

---

### Step 9 — Auto-Deploy from GitHub (Optional)

Set up a webhook so every `git push` auto-deploys:

```bash
nano /var/www/pulsemsg/deploy.sh
```

```bash
#!/bin/bash
cd /var/www/pulsemsg
git pull origin main
npm install --production
pm2 restart pulsemsg
echo "Deployed at $(date)"
```

```bash
chmod +x /var/www/pulsemsg/deploy.sh
```

Run manually to update anytime:
```bash
/var/www/pulsemsg/deploy.sh
```

---

### Useful PM2 Commands

```bash
pm2 status              # Check app status
pm2 logs pulsemsg       # View live logs
pm2 restart pulsemsg    # Restart app
pm2 stop pulsemsg       # Stop app
pm2 monit               # Live CPU/RAM monitor
```

---

## ☁️ Deploy to Netlify (Free / Serverless)

> ⚠️ Note: Scheduled SMS (setTimeout) only works on the Node.js server. Netlify Functions are stateless and won't hold scheduled jobs. For scheduling on Netlify, use Twilio's native scheduling API.

1. Push your code to GitHub
2. Go to [netlify.com](https://netlify.com) → **Add new site → Import from Git**
3. Select your repo → build settings are auto-detected from `netlify.toml`
4. Click **Deploy site**
5. Go to **Site settings → Environment variables** and add:
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_PHONE_NUMBER`

---

## 🔑 Getting Twilio Credentials

1. Sign up at https://twilio.com (free trial gives ~$15 credit)
2. Dashboard → copy **Account SID** and **Auth Token**
3. Get a phone number: **Phone Numbers → Manage → Buy a number** (~$1/month)
4. **Free trial limitation:** You can only send to verified numbers
   - Verify your phone: Console → **Verified Caller IDs → Add a new Caller ID**

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Server + Twilio status check |
| `POST` | `/api/send-sms` | Send SMS immediately |
| `POST` | `/api/schedule-sms` | Schedule SMS for later |
| `DELETE` | `/api/schedule-sms/:jobId` | Cancel a scheduled SMS |

### POST `/api/send-sms` body:
```json
{
  "to": "+15551234567",
  "message": "Hello world",
  "senderName": "AlertBot",
  "priority": "high"
}
```

### POST `/api/schedule-sms` body:
```json
{
  "to": "+15551234567",
  "message": "Reminder!",
  "senderName": "ReminderBot",
  "priority": "normal",
  "sendAt": "2026-03-01T09:00:00.000Z"
}
```

---

## 📁 Project Structure

```
pulsemsg/
├── server.js                    # Express backend
├── package.json
├── .env.example                 # Env variable template (copy to .env)
├── .gitignore
├── netlify.toml                 # Netlify config
├── deploy.sh                    # VPS auto-deploy script
├── README.md
├── public/
│   └── index.html               # Frontend UI
└── netlify/
    └── functions/
        ├── send-sms.js          # Serverless SMS function
        └── health.js            # Health check function
```

---

## ✨ Features

- ✅ **Real SMS sending** via Twilio
- ✅ **Sender's display name** in every message
- ✅ **20+ country codes** in phone picker
- ✅ **4 priority levels** — Low / Normal / High / Critical
- ✅ **Schedule SMS** — date, time, timezone picker
- ✅ **Cancel scheduled** messages before they fire
- ✅ **Server-side scheduling** — fires even if browser is closed (VPS only)
- ✅ **Message log** — real-time status + Twilio SID tracking
- ✅ **Health indicator** — live Twilio connection status
- ✅ **Mobile responsive** — works on all screen sizes

---

## 💰 Cost Estimate

| Service | Cost |
|---------|------|
| DigitalOcean Droplet (1GB) | ~$6/month |
| Twilio phone number | ~$1/month |
| Twilio SMS (US) | ~$0.0079/message |
| SSL certificate (Let's Encrypt) | Free |
| **Total** | **~$7/month + SMS usage** |


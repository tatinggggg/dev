require('dotenv').config();
const express = require('express');
const cors = require('cors');
const twilio = require('twilio');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function getClient() {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  if (!sid || !token) throw new Error('Twilio credentials not configured in .env');
  return twilio(sid, token);
}

const scheduledJobs = {};

app.post('/api/send-sms', async (req, res) => {
  try {
    const { to, message, senderName, priority } = req.body;
    if (!to || !message) return res.status(400).json({ success: false, error: 'to and message are required.' });
    const from = process.env.TWILIO_PHONE_NUMBER;
    if (!from) return res.status(500).json({ success: false, error: 'TWILIO_PHONE_NUMBER not set in .env' });
    const priorityTag = priority ? `[${priority.toUpperCase()}]` : '';
    const senderTag = senderName ? `[${senderName}]` : '';
    const body = `${priorityTag}${senderTag} ${message}`.trim();
    const client = getClient();
    const result = await client.messages.create({ body, from, to });
    console.log(`SMS sent | SID: ${result.sid} | To: ${to}`);
    return res.json({ success: true, sid: result.sid, status: result.status, to: result.to, dateCreated: result.dateCreated });
  } catch (err) {
    console.error('SMS error:', err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/schedule-sms', async (req, res) => {
  try {
    const { to, message, senderName, priority, sendAt } = req.body;
    if (!to || !message || !sendAt) return res.status(400).json({ success: false, error: 'to, message, and sendAt are required.' });
    const fireAt = new Date(sendAt);
    const delay = fireAt - Date.now();
    if (delay <= 0) return res.status(400).json({ success: false, error: 'sendAt must be in the future.' });
    const jobId = `job_${Date.now()}`;
    scheduledJobs[jobId] = setTimeout(async () => {
      try {
        const from = process.env.TWILIO_PHONE_NUMBER;
        const priorityTag = priority ? `[${priority.toUpperCase()}]` : '';
        const senderTag = senderName ? `[${senderName}]` : '';
        const body = `${priorityTag}${senderTag} ${message}`.trim();
        const client = getClient();
        const result = await client.messages.create({ body, from, to });
        console.log(`Scheduled SMS fired | Job: ${jobId} | SID: ${result.sid}`);
      } catch (e) {
        console.error(`Scheduled SMS failed | Job: ${jobId}:`, e.message);
      } finally {
        delete scheduledJobs[jobId];
      }
    }, delay);
    console.log(`SMS scheduled | Job: ${jobId} | To: ${to} | At: ${fireAt.toISOString()}`);
    return res.json({ success: true, jobId, scheduledFor: fireAt.toISOString(), delayMs: delay });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/schedule-sms/:jobId', (req, res) => {
  const { jobId } = req.params;
  if (scheduledJobs[jobId]) {
    clearTimeout(scheduledJobs[jobId]);
    delete scheduledJobs[jobId];
    return res.json({ success: true, cancelled: jobId });
  }
  return res.status(404).json({ success: false, error: 'Job not found.' });
});

app.get('/api/health', (req, res) => {
  const configured = !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER);
  res.json({ status: 'ok', twilioConfigured: configured, scheduledJobs: Object.keys(scheduledJobs).length, uptime: Math.floor(process.uptime()) + 's' });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => {
  console.log(`\nPulseMsg server running at http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health\n`);
});

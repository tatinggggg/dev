#!/bin/bash
# PulseMsg — Auto-deploy script for DigitalOcean VPS
# Run this on your server to pull latest changes and restart
set -e

echo "🚀 PulseMsg Deploy Starting..."
echo "================================"

APP_DIR="/var/www/pulsemsg"

cd $APP_DIR

echo "📥 Pulling latest from GitHub..."
git pull origin main

echo "📦 Installing dependencies..."
npm install --production

echo "♻️  Restarting PM2 process..."
pm2 restart pulsemsg || pm2 start server.js --name pulsemsg

echo "💾 Saving PM2 state..."
pm2 save

echo "================================"
echo "✅ Deploy complete at $(date)"
pm2 status pulsemsg

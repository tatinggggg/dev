const twilio = require('twilio');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  try {
    const { to, message, senderName, priority } = JSON.parse(event.body);
    if (!to || !message) return { statusCode: 400, body: JSON.stringify({ success: false, error: 'to and message are required.' }) };
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_PHONE_NUMBER;
    if (!sid || !token || !from) return { statusCode: 500, body: JSON.stringify({ success: false, error: 'Twilio env vars not set.' }) };
    const client = twilio(sid, token);
    const body = `${priority ? '['+priority.toUpperCase()+']' : ''}${senderName ? '['+senderName+']' : ''} ${message}`.trim();
    const result = await client.messages.create({ body, from, to });
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: true, sid: result.sid, status: result.status, to: result.to }) };
  } catch (err) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: err.message }) };
  }
};

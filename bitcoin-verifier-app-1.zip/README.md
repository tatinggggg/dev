# Bitcoin Transaction Verifier - Android APK

## 📱 Mobile App Version

This is the Android APK version of the Bitcoin Transaction Verifier web application.

## ✨ Features

- ✓ Address Verification (Legacy, P2SH, Bech32)
- 🔍 Transaction Decoder
- 🔨 Transaction Builder with UTXO Lookup
- 📒 Address Book Management
- 📱 Fully Mobile Responsive
- 🌙 Dark Theme UI

## 🔧 Building the APK

### Method 1: Using Android Studio (Recommended)

1. **Install Android Studio**
   - Download from: https://developer.android.com/studio
   - Install Android SDK and build tools

2. **Create New Project**
   - Open Android Studio
   - Create a new "Empty Activity" project
   - Package name: `com.joshuaomobola.btcverifier`
   - Language: Java
   - Minimum SDK: API 21 (Android 5.0)

3. **Add Files**
   - Copy `index.html` to `app/src/main/assets/` directory
   - Replace `AndroidManifest.xml` in `app/src/main/` with the provided one
   - Replace `MainActivity.java` in `app/src/main/java/com/joshuaomobola/btcverifier/` with the provided one
   - Update `app/build.gradle` with the provided configuration

4. **Build APK**
   - Click: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK will be in: `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Using Command Line (with Android SDK)

```bash
# Set up Android SDK path
export ANDROID_HOME=/path/to/android/sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# Build APK
./gradlew assembleDebug

# APK will be generated at:
# app/build/outputs/apk/debug/app-debug.apk
```

### Method 3: Using Online APK Builder (Easiest)

**AppsGeyser** (https://appsgeyser.com)
1. Go to AppsGeyser website
2. Choose "Website" template
3. Upload the `index.html` file
4. Set app name: "BTC Verifier"
5. Set icon and splash screen
6. Generate APK

**Appy Pie** (https://www.appypie.com)
1. Create account on Appy Pie
2. Choose "Website to App" converter
3. Upload HTML file or enter the hosted URL
4. Customize appearance
5. Build and download APK

## 📦 Project Structure

```
btc-verifier-app/
├── index.html              # Main web application
├── AndroidManifest.xml     # Android app manifest
├── MainActivity.java       # Main activity (WebView wrapper)
├── build.gradle           # Build configuration
└── README.md              # This file
```

## 🔐 Permissions Required

- `INTERNET` - For potential future API calls
- `ACCESS_NETWORK_STATE` - To check network connectivity

## 📋 Installation

1. Enable "Install from Unknown Sources" on your Android device:
   - Settings → Security → Unknown Sources → Enable
   
2. Transfer the APK to your device

3. Tap the APK file to install

4. Launch "BTC Verifier" from your app drawer

## 🎨 App Details

- **Package Name:** com.joshuaomobola.btcverifier
- **Version:** 1.0
- **Minimum Android Version:** 5.0 (API 21)
- **Target Android Version:** 13 (API 33)
- **Orientation:** Portrait (can be changed to landscape in manifest)

## 🔄 Updates

To update the app with changes:
1. Modify `index.html`
2. Increment `versionCode` and `versionName` in build.gradle
3. Rebuild the APK
4. Install over the existing app

## 🐛 Troubleshooting

**WebView not loading:**
- Ensure JavaScript is enabled in MainActivity
- Check that index.html is in the correct assets folder

**App crashes on startup:**
- Verify AndroidManifest.xml permissions
- Check LogCat for error messages

**Features not working:**
- Clear app data: Settings → Apps → BTC Verifier → Clear Data
- Reinstall the app

## 📄 License

This app is for educational and personal use.

## 👨‍💻 Developer

**Developed by:** Joshua Omobola

## 🤝 Support

For issues or questions, please contact the developer.

---

**Note:** This app works entirely offline after installation. All Bitcoin address validation and transaction building happens locally on your device. No data is sent to external servers.
